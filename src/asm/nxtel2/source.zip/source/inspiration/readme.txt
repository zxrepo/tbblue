SPECTACLE
=========

http://www.worldofspectrum.org/infoseekid.cgi?id=0009269
http://www.worldofspectrum.org/infoseekid.cgi?id=0009270

SPECTACLE is (c) 1984, 1986 Slimy Green Publications, by kind permission.